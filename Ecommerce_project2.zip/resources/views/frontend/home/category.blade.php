<!-- category-section -->
<section class="category-section centred">
	<div class="auto-container">
	<div class="inner-container wow slideInLeft animated" data-wow-delay="00ms" data-wow-duration="1500ms">
	<ul class="category-list clearfix">
	<li>
	<div class="category-block-one">
	<div class="inner-box">
	<div class="icon-box"><i class="icon-1"></i></div>
	<h5><a href="property-details.html">Residential</a></h5>
	<span>52</span>
	</div>
	</div>
	</li>
	<li>
	<div class="category-block-one">
	<div class="inner-box">
	<div class="icon-box"><i class="icon-2"></i></div>
	<h5><a href="property-details.html">Commercial</a></h5>
	<span>20</span>
	</div>
	</div>
	</li>
	<li>
	<div class="category-block-one">
	<div class="inner-box">
	<div class="icon-box"><i class="icon-3"></i></div>
	<h5><a href="property-details.html">Appertment</a></h5>
	<span>35</span>
	</div>
	</div>
	</li>
	<li>
	<div class="category-block-one">
	<div class="inner-box">
	<div class="icon-box"><i class="icon-4"></i></div>
	<h5><a href="property-details.html">Industrial</a></h5>
	<span>10</span>
	</div>
	</div>
	</li>
	<li>
	<div class="category-block-one">
	<div class="inner-box">
	<div class="icon-box"><i class="icon-5"></i></div>
	<h5><a href="property-details.html">Building Code</a></h5>
	<span>27</span>
	</div>
	</div>
	</li>
	</ul>
	<div class="more-btn"><a href="categories.html" class="theme-btn btn-one">All Categories</a></div>
	</div>
	</div>
	</section>
	<!-- category-section end -->