


<?php $__env->startSection('admin'); ?>
<div class="page-content">
  

    <nav class="page-breadcrumb">
        <ol class="breadcrumb">
       <a href="<?php echo e(route('add.Property')); ?>" class="btn btn-inverse-info"> Add Property </a>
        </ol>
    </nav>

    <div class="row">
        <div class="col-md-12 grid-margin stretch-card">
<div class="card">
  <div class="card-body">
    <h6 class="card-title">All property Types</h6>
    
    <div class="table-responsive">
      <table id="dataTableExample" class="table">
        <thead>
          <tr>
            <th>#</th>

            <th>Image</th>

            <th>Name</th>

            <th>P Type</th>


            <th>Status Type</th>

            <th>City</th>

            <th>Code</th>

            <th>Status</th>

            
            

            <th>Action</th>
           
          </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($key+1); ?></td>
            <td><img src="<?php echo e(asset($property->property_thambnail)); ?>"
               alt="property_img" style="height: 40px;width:70px"></td>
               <td><?php echo e($property->property_name); ?></td> 
               <td><?php echo e($property["type"]["type_name"]); ?></td> 
               <td><?php echo e($property->property_status); ?></td> 
               <td><?php echo e($property->city); ?></td> 
               <td><?php echo e($property->property_code); ?></td> 
               
               
               <td> 
                      <?php if($property->status == 1): ?>
                <span class="badge rounded-pill bg-success">Active</span>
                      <?php else: ?>
               <span class="badge rounded-pill bg-danger">InActive</span>
                      <?php endif; ?>

               </td> 
            <td>
                <a href="<?php echo e(route('edit.property',$property->id)); ?>" class="btn btn-inverse-warning">Edit</a>
                <a href="<?php echo e(route('delete.property',$property->id)); ?>" class="btn btn-inverse-danger" id="delete">Delete</a>
            </td>
           
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
        </div>
    </div>

</div>
    
<?php $__env->stopSection(); ?>


<?php echo $__env->make("admin.admin_dashboard", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\New folder\Ecommerce_project2\resources\views/backend/property/all_property.blade.php ENDPATH**/ ?>